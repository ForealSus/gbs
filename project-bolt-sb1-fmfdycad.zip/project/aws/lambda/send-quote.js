const AWS = require('aws-sdk');

// Initialize AWS SES
const ses = new AWS.SES({
  region: process.env.AWS_REGION || 'us-east-1'
});

exports.handler = async (event) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };

  // Handle preflight OPTIONS request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    // Parse request body
    const { name, email, message, to } = JSON.parse(event.body);

    // Validate required fields
    if (!name || !email || !message) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: 'Missing required fields: name, email, message'
        })
      };
    }

    // Email parameters
    const params = {
      Source: 'noreply@alokaryanusantara.com', // Must be verified in SES
      Destination: {
        ToAddresses: [to || 'rafian@alokaryanusantara.com']
      },
      Message: {
        Subject: {
          Data: `New Quote Request from ${name}`,
          Charset: 'UTF-8'
        },
        Body: {
          Html: {
            Data: `
              <html>
                <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                  <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <div style="background: linear-gradient(135deg, #ea580c, #f97316); padding: 30px; border-radius: 10px 10px 0 0; text-align: center;">
                      <h1 style="color: white; margin: 0; font-size: 24px;">New Quote Request</h1>
                      <p style="color: #fed7aa; margin: 10px 0 0 0;">Alokarya Nusantara</p>
                    </div>
                    
                    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 10px 10px; border: 1px solid #e2e8f0;">
                      <h2 style="color: #1f2937; margin-top: 0;">Client Information</h2>
                      
                      <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #ea580c;">
                        <p style="margin: 0 0 10px 0;"><strong>Name:</strong> ${name}</p>
                        <p style="margin: 0;"><strong>Email:</strong> <a href="mailto:${email}" style="color: #ea580c;">${email}</a></p>
                      </div>
                      
                      <h3 style="color: #1f2937; margin-bottom: 15px;">Project Details</h3>
                      <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #ea580c;">
                        <p style="margin: 0; white-space: pre-wrap;">${message}</p>
                      </div>
                      
                      <div style="margin-top: 30px; padding: 20px; background: #fef3c7; border-radius: 8px; border-left: 4px solid #f59e0b;">
                        <p style="margin: 0; color: #92400e;"><strong>Action Required:</strong> Please respond to this quote request within 24 hours.</p>
                      </div>
                    </div>
                    
                    <div style="text-align: center; margin-top: 20px; color: #6b7280; font-size: 14px;">
                      <p>This email was sent from the Alokarya Nusantara website quote form.</p>
                      <p>Timestamp: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}</p>
                    </div>
                  </div>
                </body>
              </html>
            `,
            Charset: 'UTF-8'
          },
          Text: {
            Data: `
New Quote Request - Alokarya Nusantara

Client Information:
Name: ${name}
Email: ${email}

Project Details:
${message}

Please respond to this quote request within 24 hours.

Timestamp: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
            `,
            Charset: 'UTF-8'
          }
        }
      }
    };

    // Send email
    const result = await ses.sendEmail(params).promise();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        messageId: result.MessageId,
        message: 'Quote request sent successfully'
      })
    };

  } catch (error) {
    console.error('Error sending email:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Failed to send quote request',
        details: error.message
      })
    };
  }
};