# AWS SES Integration for Alokarya Nusantara

This directory contains the AWS infrastructure setup for the quote form email functionality.

## Prerequisites

1. AWS Account with appropriate permissions
2. AWS CLI configured
3. Domain `alokaryanusantara.com` ready for DNS configuration

## Deployment Steps

### 1. Deploy CloudFormation Stack

```bash
aws cloudformation create-stack \
  --stack-name alokarya-ses-stack \
  --template-body file://cloudformation/ses-setup.yaml \
  --parameters ParameterKey=DomainName,ParameterValue=alokaryanusantara.com \
  --capabilities CAPABILITY_IAM \
  --region us-east-1
```

### 2. Verify Domain in SES

1. Go to AWS SES Console
2. Navigate to "Verified identities"
3. Click "Create identity" → "Domain"
4. Enter `alokaryanusantara.com`
5. Add the provided DNS records to your domain:
   - CNAME record for domain verification
   - MX record for receiving emails (optional)
   - TXT record for SPF
   - CNAME records for DKIM

### 3. Verify Email Addresses

Verify these email addresses in SES:
- `noreply@alokaryanusantara.com` (sender)
- `info@alokaryanusantara.com` (backup)
- `rafian@alokaryanusantara.com` (recipient)

### 4. Request Production Access

If you're in SES Sandbox mode:
1. Go to SES Console → Account dashboard
2. Click "Request production access"
3. Fill out the form explaining your use case
4. Wait for approval (usually 24-48 hours)

### 5. Update Frontend Configuration

After deployment, update the frontend to use the API Gateway endpoint:

```javascript
// In src/components/QuoteForm.tsx
const response = await fetch('https://YOUR_API_ID.execute-api.us-east-1.amazonaws.com/prod/send-quote', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    name: formData.name,
    email: formData.email,
    message: formData.message,
    to: 'rafian@alokaryanusantara.com'
  }),
});
```

## DNS Configuration

Add these records to your domain DNS:

```
# Domain Verification (replace with actual values from SES)
_amazonses.alokaryanusantara.com CNAME [verification-token].amazonses.com

# DKIM (replace with actual values from SES)
[selector1]._domainkey.alokaryanusantara.com CNAME [selector1].[region].dkim.amazonses.com
[selector2]._domainkey.alokaryanusantara.com CNAME [selector2].[region].dkim.amazonses.com
[selector3]._domainkey.alokaryanusantara.com CNAME [selector3].[region].dkim.amazonses.com

# SPF Record
alokaryanusantara.com TXT "v=spf1 include:amazonses.com ~all"

# DMARC (optional but recommended)
_dmarc.alokaryanusantara.com TXT "v=DMARC1; p=quarantine; rua=mailto:dmarc@alokaryanusantara.com"
```

## Testing

1. Test the Lambda function directly in AWS Console
2. Test the API Gateway endpoint with curl:

```bash
curl -X POST https://YOUR_API_ID.execute-api.us-east-1.amazonaws.com/prod/send-quote \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "message": "This is a test quote request"
  }'
```

3. Test the frontend form

## Monitoring

- Check CloudWatch logs for Lambda function execution
- Monitor SES sending statistics in the AWS Console
- Set up CloudWatch alarms for failed email sends

## Cost Estimation

- SES: $0.10 per 1,000 emails sent
- Lambda: First 1M requests free, then $0.20 per 1M requests
- API Gateway: $3.50 per million API calls
- CloudWatch: Minimal cost for logs and metrics

For a typical quote form with 100 submissions per month, the cost would be less than $1/month.

## Security Considerations

1. The API is public but rate-limited
2. Email addresses are validated
3. CORS is properly configured
4. No sensitive data is logged
5. Consider adding reCAPTCHA for production use

## Troubleshooting

### Common Issues:

1. **Domain not verified**: Check DNS records are correctly added
2. **Email in sandbox mode**: Request production access
3. **CORS errors**: Ensure OPTIONS method is properly configured
4. **Lambda timeout**: Increase timeout if needed (default is 3 seconds)
5. **Rate limiting**: Implement throttling if needed

### Useful Commands:

```bash
# Check stack status
aws cloudformation describe-stacks --stack-name alokarya-ses-stack

# Get API endpoint
aws cloudformation describe-stacks --stack-name alokarya-ses-stack --query 'Stacks[0].Outputs[?OutputKey==`ApiEndpoint`].OutputValue' --output text

# Check Lambda logs
aws logs describe-log-groups --log-group-name-prefix /aws/lambda/alokarya-send-quote

# Test SES sending
aws ses send-email --source noreply@alokaryanusantara.com --destination ToAddresses=test@example.com --message Subject={Data="Test"},Body={Text={Data="Test message"}}
```