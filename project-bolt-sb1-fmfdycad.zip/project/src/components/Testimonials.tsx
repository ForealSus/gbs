import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-20 relative">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
        style={{
          backgroundImage: `url('https://images.pexels.com/photos/162539/architecture-building-construction-work-162539.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop')`
        }}
      />
      <div className="absolute inset-0 bg-gray-50/90"></div>
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              What Our Clients Say
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Trusted by construction professionals across Indonesia for our reliable service and commitment to excellence.
            </p>
          </div>

          {/* Testimonial */}
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-2xl p-8 md:p-12 shadow-lg relative">
              {/* Quote Icon */}
              <div className="absolute top-6 left-6 text-orange-200">
                <Quote size={48} />
              </div>
              
              {/* Stars */}
              <div className="flex justify-center mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="text-yellow-400 fill-current" size={24} />
                ))}
              </div>
              
              {/* Testimonial Text */}
              <blockquote className="text-xl md:text-2xl text-gray-700 text-center mb-8 leading-relaxed italic">
                "Alokarya Nusantara exceeded our expectations with their professional scaffolding services. Their team was punctual, safety-conscious, and provided excellent support throughout our commercial building project. The equipment quality was outstanding, and their competitive pricing made them our go-to partner for future projects. I highly recommend their services to any construction company looking for reliable scaffolding solutions."
              </blockquote>
              
              {/* Client Info */}
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-xl">MS</span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-1">Maria Sari</h4>
                <p className="text-gray-600">Project Manager, PT Konstruksi Mandiri</p>
                <p className="text-sm text-gray-500 mt-2">Jakarta Commercial Building Project</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;