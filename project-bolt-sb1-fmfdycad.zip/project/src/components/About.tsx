import React from 'react';
import { Target, Eye } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 relative">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
        style={{
          backgroundImage: `url('https://images.pexels.com/photos/159306/construction-site-build-construction-work-159306.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop')`
        }}
      />
      <div className="absolute inset-0 bg-gray-50/90"></div>
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              About Alokarya Nusantara
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Leading the construction industry with innovative scaffolding solutions and unwavering commitment to safety and excellence.
            </p>
          </div>

          {/* Mission & Vision */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            {/* Mission */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-6">
                <div className="bg-orange-100 p-3 rounded-full mr-4">
                  <Target className="text-orange-600" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Our Mission</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">
                To provide reliable, safe, and efficient scaffolding rental services that empower construction projects across Indonesia. We are committed to delivering exceptional quality equipment and professional support that exceeds industry standards while ensuring the safety of every worker and project.
              </p>
            </div>

            {/* Vision */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <Eye className="text-blue-600" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Our Vision</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">
                To become Indonesia's most trusted scaffolding and construction support partner, recognized for innovation, safety excellence, and contribution to building the nation's infrastructure. We envision a future where every construction project benefits from our world-class equipment and expertise.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default About;