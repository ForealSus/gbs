import React from 'react';
import { Phone, Mail, MapPin, Clock, MessageCircle } from 'lucide-react';

const Contact = () => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/6283825302739', '_blank');
  };

  const handleEmailClick = () => {
    window.location.href = 'mailto:info@alokaryanusantara.com';
  };

  return (
    <section id="contact" className="py-20 relative bg-white">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-5"
        style={{
          backgroundImage: `url('https://images.pexels.com/photos/1216589/pexels-photo-1216589.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop')`
        }}
      />
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Contact Us
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Ready to discuss your scaffolding needs? Get in touch with our expert team for immediate assistance and professional consultation.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="space-y-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Get in Touch</h3>
              
              {/* WhatsApp */}
              <div 
                onClick={handleWhatsAppClick}
                className="flex items-start space-x-4 p-6 bg-green-50 rounded-xl hover:bg-green-100 transition-colors cursor-pointer group"
              >
                <div className="bg-green-500 p-3 rounded-full group-hover:bg-green-600 transition-colors">
                  <MessageCircle className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-1">WhatsApp</h4>
                  <p className="text-green-600 font-medium">+62 838-2530-2739</p>
                  <p className="text-gray-600 text-sm">Click to chat with us instantly</p>
                </div>
              </div>

              {/* Email */}
              <div 
                onClick={handleEmailClick}
                className="flex items-start space-x-4 p-6 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors cursor-pointer group"
              >
                <div className="bg-blue-500 p-3 rounded-full group-hover:bg-blue-600 transition-colors">
                  <Mail className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-1">Email</h4>
                  <p className="text-blue-600 font-medium">info@alokaryanusantara.com</p>
                  <p className="text-gray-600 text-sm">Send us your detailed requirements</p>
                </div>
              </div>

              {/* Location */}
              <div className="flex items-start space-x-4 p-6 bg-orange-50 rounded-xl">
                <div className="bg-orange-500 p-3 rounded-full">
                  <MapPin className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-1">Service Area</h4>
                  <p className="text-orange-600 font-medium">Indonesia</p>
                  <p className="text-gray-600 text-sm">Serving construction projects nationwide</p>
                </div>
              </div>

              {/* Business Hours */}
              <div className="flex items-start space-x-4 p-6 bg-gray-50 rounded-xl">
                <div className="bg-gray-500 p-3 rounded-full">
                  <Clock className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-1">Business Hours</h4>
                  <div className="text-gray-600 text-sm space-y-1">
                    <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p>Saturday: 8:00 AM - 4:00 PM</p>
                    <p>Sunday: Emergency calls only</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form CTA */}
            <div className="bg-gradient-to-br from-orange-600 to-orange-700 rounded-2xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-4">Need a Quote?</h3>
              <p className="text-orange-100 mb-6 leading-relaxed">
                Fill out our detailed quote request form and receive a customized proposal for your scaffolding needs within 24 hours.
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-orange-300 rounded-full"></div>
                  <span className="text-orange-100">Free consultation and site assessment</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-orange-300 rounded-full"></div>
                  <span className="text-orange-100">Competitive pricing with no hidden costs</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-orange-300 rounded-full"></div>
                  <span className="text-orange-100">Flexible rental terms and payment options</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-orange-300 rounded-full"></div>
                  <span className="text-orange-100">Professional installation and support</span>
                </div>
              </div>
              
              <button 
                onClick={() => document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white text-orange-600 px-8 py-3 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors w-full"
              >
                Request Quote Now
              </button>
            </div>
          </div>

          {/* Emergency Contact */}
          <div className="mt-16 text-center bg-red-50 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Emergency Support</h3>
            <p className="text-gray-600 mb-4">
              For urgent scaffolding issues or emergency support, contact us immediately via WhatsApp or phone.
            </p>
            <button 
              onClick={handleWhatsAppClick}
              className="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors"
            >
              Emergency Contact
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;