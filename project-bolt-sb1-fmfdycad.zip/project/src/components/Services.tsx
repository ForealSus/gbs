import React from 'react';
import { Building, Truck, Settings, HeadphonesIcon } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Building,
      title: "Scaffolding Rental",
      description: "Complete scaffolding systems for residential, commercial, and industrial construction projects. All equipment meets international safety standards.",
      features: ["Modular scaffolding systems", "Custom configurations", "Safety accessories included", "Flexible rental periods"]
    },
    {
      icon: Truck,
      title: "Delivery & Installation",
      description: "Professional delivery, setup, and dismantling services by our certified technicians. We ensure proper installation for maximum safety.",
      features: ["On-time delivery", "Professional installation", "Safety inspection", "Dismantling service"]
    },
    {
      icon: Settings,
      title: "Maintenance & Support",
      description: "Regular maintenance checks and technical support throughout your project duration. Our team ensures optimal performance and safety.",
      features: ["Regular inspections", "Maintenance service", "Technical support", "Emergency repairs"]
    },
    {
      icon: HeadphonesIcon,
      title: "Consultation Services",
      description: "Expert consultation for scaffolding planning and safety compliance. We help optimize your construction workflow and ensure regulatory compliance.",
      features: ["Project planning", "Safety compliance", "Cost optimization", "Technical guidance"]
    }
  ];

  return (
    <section id="services" className="py-20 relative bg-white">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-5"
        style={{
          backgroundImage: `url('https://images.pexels.com/photos/585419/pexels-photo-585419.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop')`
        }}
      />
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Our Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Comprehensive scaffolding solutions tailored to meet your construction project needs with the highest standards of safety and efficiency.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-gray-50 rounded-2xl p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="flex items-center mb-6">
                  <div className="bg-orange-100 p-4 rounded-full mr-4">
                    <service.icon className="text-orange-600" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">{service.title}</h3>
                </div>
                
                <p className="text-gray-700 text-lg mb-6 leading-relaxed">
                  {service.description}
                </p>
                
                <ul className="space-y-3">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-600">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* CTA Section */}
          <div className="text-center mt-16">
            <div className="bg-gradient-to-r from-orange-600 to-orange-700 rounded-2xl p-8 text-white">
              <h3 className="text-3xl font-bold mb-4">Ready to Start Your Project?</h3>
              <p className="text-xl mb-6 text-orange-100">
                Get a customized quote for your scaffolding needs today
              </p>
              <button 
                onClick={() => document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white text-orange-600 px-8 py-3 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors"
              >
                Request Quote Now
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;