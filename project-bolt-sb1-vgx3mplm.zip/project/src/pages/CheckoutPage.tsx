import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { CreditCard, Lock, Check, ArrowLeft, Server, Cpu } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useUser } from '../contexts/UserContext';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface ServicePlan {
  id: string;
  name: string;
  type: 'vps' | 'ml';
  cpu: number;
  ram: number;
  storage: number;
  gpu?: string;
  price: number;
  features: string[];
}

const CheckoutPage: React.FC = () => {
  const { serviceId } = useParams<{ serviceId: string }>();
  const { user } = useAuth();
  const { addService } = useUser();
  const navigate = useNavigate();
  
  const [paymentMethod, setPaymentMethod] = useState('credit-card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: '',
    billingAddress: '',
    city: '',
    postalCode: ''
  });

  // Service plans data (same as ServicesPage)
  const allPlans: ServicePlan[] = [
    // VPS Plans
    {
      id: 'vps-starter',
      name: 'VPS Starter',
      type: 'vps',
      cpu: 2,
      ram: 4,
      storage: 50,
      price: 29,
      features: ['2 vCPU Cores', '4 GB RAM', '50 GB SSD Storage', '1 TB Bandwidth', '99.9% Uptime SLA', 'DDoS Protection', '24/7 Support']
    },
    {
      id: 'vps-professional',
      name: 'VPS Professional',
      type: 'vps',
      cpu: 4,
      ram: 8,
      storage: 100,
      price: 59,
      features: ['4 vCPU Cores', '8 GB RAM', '100 GB SSD Storage', '2 TB Bandwidth', '99.9% Uptime SLA', 'DDoS Protection', 'Free SSL Certificate', '24/7 Priority Support']
    },
    {
      id: 'vps-enterprise',
      name: 'VPS Enterprise',
      type: 'vps',
      cpu: 8,
      ram: 16,
      storage: 200,
      price: 119,
      features: ['8 vCPU Cores', '16 GB RAM', '200 GB SSD Storage', '5 TB Bandwidth', '99.9% Uptime SLA', 'Advanced DDoS Protection', 'Free SSL Certificate', 'Dedicated Support Manager', 'Custom Configurations']
    },
    {
      id: 'vps-ultimate',
      name: 'VPS Ultimate',
      type: 'vps',
      cpu: 16,
      ram: 32,
      storage: 500,
      price: 239,
      features: ['16 vCPU Cores', '32 GB RAM', '500 GB SSD Storage', '10 TB Bandwidth', '99.99% Uptime SLA', 'Enterprise DDoS Protection', 'Free SSL Certificate', 'Dedicated Support Manager', 'Custom Configurations', 'Priority Resource Allocation']
    },
    // ML Plans
    {
      id: 'ml-basic',
      name: 'ML Basic',
      type: 'ml',
      cpu: 4,
      ram: 16,
      storage: 100,
      gpu: 'NVIDIA T4 (16GB)',
      price: 149,
      features: ['NVIDIA T4 GPU (16GB VRAM)', '4 vCPU Cores', '16 GB RAM', '100 GB SSD Storage', 'CUDA & cuDNN Pre-installed', 'Jupyter Notebook Access', 'TensorFlow & PyTorch Ready', '24/7 Support']
    },
    {
      id: 'ml-professional',
      name: 'ML Professional',
      type: 'ml',
      cpu: 8,
      ram: 32,
      storage: 250,
      gpu: 'NVIDIA T4 (16GB)',
      price: 299,
      features: ['NVIDIA T4 GPU (16GB VRAM)', '8 vCPU Cores', '32 GB RAM', '250 GB SSD Storage', 'CUDA & cuDNN Pre-installed', 'Jupyter Notebook Access', 'TensorFlow & PyTorch Ready', 'Docker Support', 'Custom ML Frameworks', '24/7 Priority Support']
    },
    {
      id: 'ml-enterprise',
      name: 'ML Enterprise',
      type: 'ml',
      cpu: 16,
      ram: 64,
      storage: 500,
      gpu: '2x NVIDIA T4 (32GB)',
      price: 599,
      features: ['2x NVIDIA T4 GPU (32GB VRAM)', '16 vCPU Cores', '64 GB RAM', '500 GB SSD Storage', 'CUDA & cuDNN Pre-installed', 'Jupyter Notebook Access', 'TensorFlow & PyTorch Ready', 'Docker & Kubernetes Support', 'Custom ML Frameworks', 'Dedicated Support Manager', 'Multi-GPU Training Support']
    },
    {
      id: 'ml-ultimate',
      name: 'ML Ultimate',
      type: 'ml',
      cpu: 32,
      ram: 128,
      storage: 1000,
      gpu: '4x NVIDIA T4 (64GB)',
      price: 1199,
      features: ['4x NVIDIA T4 GPU (64GB VRAM)', '32 vCPU Cores', '128 GB RAM', '1000 GB SSD Storage', 'CUDA & cuDNN Pre-installed', 'Jupyter Notebook Access', 'TensorFlow & PyTorch Ready', 'Docker & Kubernetes Support', 'Custom ML Frameworks', 'Dedicated Support Manager', 'Multi-GPU Training Support', 'Priority Resource Allocation', 'Custom Infrastructure Setup']
    }
  ];

  const selectedPlan = allPlans.find(plan => plan.id === serviceId);

  if (!user) {
    navigate('/login');
    return null;
  }

  if (!selectedPlan) {
    navigate('/services');
    return null;
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Add service to user's account
    addService({
      name: selectedPlan.name,
      type: selectedPlan.type,
      cpu: selectedPlan.cpu,
      ram: selectedPlan.ram,
      storage: selectedPlan.storage,
      gpu: selectedPlan.gpu,
      price: selectedPlan.price
    });

    setIsProcessing(false);
    navigate('/dashboard');
  };

  const tax = selectedPlan.price * 0.11; // 11% VAT
  const total = selectedPlan.price + tax;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <button
          onClick={() => navigate('/services')}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 mb-8"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Services</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Order Summary */}
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-8">Order Summary</h1>
            
            <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
              <div className="flex items-center space-x-4 mb-6">
                <div className={`p-3 rounded-lg ${selectedPlan.type === 'ml' ? 'bg-purple-100' : 'bg-blue-100'}`}>
                  {selectedPlan.type === 'ml' ? (
                    <Cpu className={`h-8 w-8 ${selectedPlan.type === 'ml' ? 'text-purple-600' : 'text-blue-600'}`} />
                  ) : (
                    <Server className={`h-8 w-8 ${selectedPlan.type === 'ml' ? 'text-purple-600' : 'text-blue-600'}`} />
                  )}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{selectedPlan.name}</h2>
                  <p className="text-gray-600">
                    {selectedPlan.type === 'ml' ? 'ML GPU Cloud' : 'Cloud VPS'}
                  </p>
                </div>
              </div>

              {/* Specifications */}
              <div className="grid grid-cols-2 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-600">CPU</p>
                  <p className="font-semibold">{selectedPlan.cpu} vCores</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">RAM</p>
                  <p className="font-semibold">{selectedPlan.ram} GB</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Storage</p>
                  <p className="font-semibold">{selectedPlan.storage} GB SSD</p>
                </div>
                {selectedPlan.gpu && (
                  <div>
                    <p className="text-sm text-gray-600">GPU</p>
                    <p className="font-semibold text-purple-600">{selectedPlan.gpu}</p>
                  </div>
                )}
              </div>

              {/* Features */}
              <div className="mb-6">
                <h3 className="font-semibold text-gray-900 mb-3">Included Features</h3>
                <ul className="space-y-2">
                  {selectedPlan.features.slice(0, 5).map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2 text-sm">
                      <Check className="h-4 w-4 text-green-500" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                  {selectedPlan.features.length > 5 && (
                    <li className="text-sm text-gray-500">
                      +{selectedPlan.features.length - 5} more features
                    </li>
                  )}
                </ul>
              </div>

              {/* Pricing */}
              <div className="border-t pt-4">
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Monthly Price</span>
                  <span className="font-semibold">${selectedPlan.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">VAT (11%)</span>
                  <span className="font-semibold">${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-lg font-bold border-t pt-2">
                  <span>Total Monthly</span>
                  <span className={selectedPlan.type === 'ml' ? 'text-purple-600' : 'text-blue-600'}>
                    ${total.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Payment Information</h2>
            
            <div className="bg-white rounded-lg shadow-lg p-6">
              {/* Payment Method Selection */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Method</h3>
                <div className="space-y-3">
                  <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="credit-card"
                      checked={paymentMethod === 'credit-card'}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="text-blue-600"
                    />
                    <CreditCard className="h-5 w-5 text-gray-600" />
                    <span className="font-medium">Credit/Debit Card</span>
                  </label>
                  
                  <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="bank-transfer"
                      checked={paymentMethod === 'bank-transfer'}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="text-blue-600"
                    />
                    <div className="w-5 h-5 bg-green-100 rounded flex items-center justify-center">
                      <div className="w-2 h-2 bg-green-600 rounded"></div>
                    </div>
                    <span className="font-medium">Bank Transfer</span>
                  </label>
                </div>
              </div>

              {/* Payment Form */}
              <form onSubmit={handleSubmit} className="space-y-6">
                {paymentMethod === 'credit-card' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Card Number
                      </label>
                      <input
                        type="text"
                        name="cardNumber"
                        required
                        value={formData.cardNumber}
                        onChange={handleInputChange}
                        placeholder="1234 5678 9012 3456"
                        className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Expiry Date
                        </label>
                        <input
                          type="text"
                          name="expiryDate"
                          required
                          value={formData.expiryDate}
                          onChange={handleInputChange}
                          placeholder="MM/YY"
                          className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          CVV
                        </label>
                        <input
                          type="text"
                          name="cvv"
                          required
                          value={formData.cvv}
                          onChange={handleInputChange}
                          placeholder="123"
                          className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Cardholder Name
                      </label>
                      <input
                        type="text"
                        name="cardName"
                        required
                        value={formData.cardName}
                        onChange={handleInputChange}
                        placeholder="John Doe"
                        className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </>
                )}

                {/* Billing Address */}
                <div className="border-t pt-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Billing Address</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Address
                      </label>
                      <input
                        type="text"
                        name="billingAddress"
                        required
                        value={formData.billingAddress}
                        onChange={handleInputChange}
                        placeholder="123 Main Street"
                        className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          City
                        </label>
                        <input
                          type="text"
                          name="city"
                          required
                          value={formData.city}
                          onChange={handleInputChange}
                          placeholder="Jakarta"
                          className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Postal Code
                        </label>
                        <input
                          type="text"
                          name="postalCode"
                          required
                          value={formData.postalCode}
                          onChange={handleInputChange}
                          placeholder="12345"
                          className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Security Notice */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Lock className="h-4 w-4" />
                    <span>Your payment information is encrypted and secure</span>
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className={`w-full py-4 px-6 rounded-lg font-semibold text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                    selectedPlan.type === 'ml'
                      ? 'bg-purple-600 hover:bg-purple-700'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {isProcessing ? (
                    <span>Processing Payment...</span>
                  ) : (
                    <span>Complete Order - ${total.toFixed(2)}/month</span>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default CheckoutPage;