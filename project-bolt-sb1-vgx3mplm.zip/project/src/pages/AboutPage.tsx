import React from 'react';
import { Shield, Award, Users, Globe, Zap, Heart } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-indigo-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            About AloCloud Solutions
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            We're pioneering the future of cloud infrastructure with cutting-edge technology 
            and unwavering commitment to excellence.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                At AloCloud Solutions, we believe that powerful cloud infrastructure should be 
                accessible to businesses of all sizes. Our mission is to democratize access to 
                enterprise-grade cloud computing resources while maintaining the highest standards 
                of performance, security, and reliability.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                We specialize in providing high-performance virtual private servers and 
                GPU-accelerated machine learning platforms that empower developers, researchers, 
                and businesses to innovate without limitations.
              </p>
              <div className="flex items-center space-x-4">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <Heart className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Built with Passion</h3>
                  <p className="text-gray-600">Every solution crafted with care and precision</p>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-8 rounded-xl">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">99.9%</div>
                  <div className="text-sm text-gray-600">Uptime SLA</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">24/7</div>
                  <div className="text-sm text-gray-600">Expert Support</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">3</div>
                  <div className="text-sm text-gray-600">Data Centers</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">1000+</div>
                  <div className="text-sm text-gray-600">Happy Clients</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              These principles guide everything we do and shape our commitment to excellence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Shield className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Security First</h3>
              <p className="text-gray-600">
                We implement enterprise-grade security measures to protect your data and 
                infrastructure with advanced encryption and monitoring systems.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Award className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Excellence</h3>
              <p className="text-gray-600">
                We strive for perfection in every aspect of our service, from infrastructure 
                performance to customer support and user experience.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Customer-Centric</h3>
              <p className="text-gray-600">
                Our customers are at the heart of everything we do. We listen, adapt, and 
                continuously improve based on your feedback and needs.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-orange-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Zap className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Innovation</h3>
              <p className="text-gray-600">
                We embrace cutting-edge technologies and continuously evolve our platform 
                to stay ahead of industry trends and requirements.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-teal-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Globe className="h-6 w-6 text-teal-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Global Reach</h3>
              <p className="text-gray-600">
                With strategically located data centers across Indonesia, we provide 
                low-latency access and reliable service to users nationwide.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-pink-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Heart className="h-6 w-6 text-pink-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Transparency</h3>
              <p className="text-gray-600">
                We believe in honest communication, transparent pricing, and clear service 
                level agreements with no hidden fees or surprises.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Infrastructure Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Infrastructure
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              State-of-the-art data centers strategically located across Indonesia 
              to provide optimal performance and reliability.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-8 rounded-xl mb-6">
                <h3 className="text-2xl font-bold mb-2">Jakarta</h3>
                <p className="text-blue-100">Primary Data Center</p>
                <div className="mt-4 text-sm">
                  <div className="bg-blue-400 bg-opacity-30 rounded-lg p-3">
                    <p>Tier III Certified</p>
                    <p>99.99% Uptime</p>
                    <p>24/7 Monitoring</p>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                Our flagship facility in Jakarta serves as the primary hub for our cloud infrastructure, 
                featuring the latest hardware and redundant systems.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-8 rounded-xl mb-6">
                <h3 className="text-2xl font-bold mb-2">Bandung</h3>
                <p className="text-green-100">Secondary Data Center</p>
                <div className="mt-4 text-sm">
                  <div className="bg-green-400 bg-opacity-30 rounded-lg p-3">
                    <p>Tier III Certified</p>
                    <p>99.99% Uptime</p>
                    <p>Disaster Recovery</p>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                Our Bandung facility provides additional capacity and serves as a backup location 
                for critical workloads and disaster recovery scenarios.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-8 rounded-xl mb-6">
                <h3 className="text-2xl font-bold mb-2">Yogyakarta</h3>
                <p className="text-purple-100">Edge Data Center</p>
                <div className="mt-4 text-sm">
                  <div className="bg-purple-400 bg-opacity-30 rounded-lg p-3">
                    <p>Tier II+ Certified</p>
                    <p>99.9% Uptime</p>
                    <p>Low Latency</p>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                Our Yogyakarta edge location provides low-latency access for users in Central Java 
                and surrounding regions with optimized performance.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Built by Experts
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">
            Our team consists of experienced cloud architects, DevOps engineers, and infrastructure 
            specialists who are passionate about delivering exceptional cloud solutions.
          </p>
          
          <div className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">50+ Engineers</h3>
                <p className="text-gray-600">Dedicated cloud infrastructure specialists</p>
              </div>
              
              <div className="text-center">
                <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">10+ Years</h3>
                <p className="text-gray-600">Average industry experience</p>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">24/7 Support</h3>
                <p className="text-gray-600">Round-the-clock expert assistance</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default AboutPage;