import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Server, Cpu, HardDrive, Zap, Check } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface ServicePlan {
  id: string;
  name: string;
  type: 'vps' | 'ml';
  cpu: number;
  ram: number;
  storage: number;
  gpu?: string;
  price: number;
  features: string[];
  popular?: boolean;
}

const ServicesPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'vps' | 'ml'>('vps');

  const vpsPlans: ServicePlan[] = [
    {
      id: 'vps-starter',
      name: 'VPS Starter',
      type: 'vps',
      cpu: 2,
      ram: 4,
      storage: 50,
      price: 29,
      features: [
        '2 vCPU Cores',
        '4 GB RAM',
        '50 GB SSD Storage',
        '1 TB Bandwidth',
        '99.9% Uptime SLA',
        'DDoS Protection',
        '24/7 Support'
      ]
    },
    {
      id: 'vps-professional',
      name: 'VPS Professional',
      type: 'vps',
      cpu: 4,
      ram: 8,
      storage: 100,
      price: 59,
      popular: true,
      features: [
        '4 vCPU Cores',
        '8 GB RAM',
        '100 GB SSD Storage',
        '2 TB Bandwidth',
        '99.9% Uptime SLA',
        'DDoS Protection',
        'Free SSL Certificate',
        '24/7 Priority Support'
      ]
    },
    {
      id: 'vps-enterprise',
      name: 'VPS Enterprise',
      type: 'vps',
      cpu: 8,
      ram: 16,
      storage: 200,
      price: 119,
      features: [
        '8 vCPU Cores',
        '16 GB RAM',
        '200 GB SSD Storage',
        '5 TB Bandwidth',
        '99.9% Uptime SLA',
        'Advanced DDoS Protection',
        'Free SSL Certificate',
        'Dedicated Support Manager',
        'Custom Configurations'
      ]
    },
    {
      id: 'vps-ultimate',
      name: 'VPS Ultimate',
      type: 'vps',
      cpu: 16,
      ram: 32,
      storage: 500,
      price: 239,
      features: [
        '16 vCPU Cores',
        '32 GB RAM',
        '500 GB SSD Storage',
        '10 TB Bandwidth',
        '99.99% Uptime SLA',
        'Enterprise DDoS Protection',
        'Free SSL Certificate',
        'Dedicated Support Manager',
        'Custom Configurations',
        'Priority Resource Allocation'
      ]
    }
  ];

  const mlPlans: ServicePlan[] = [
    {
      id: 'ml-basic',
      name: 'ML Basic',
      type: 'ml',
      cpu: 4,
      ram: 16,
      storage: 100,
      gpu: 'NVIDIA T4 (16GB)',
      price: 149,
      features: [
        'NVIDIA T4 GPU (16GB VRAM)',
        '4 vCPU Cores',
        '16 GB RAM',
        '100 GB SSD Storage',
        'CUDA & cuDNN Pre-installed',
        'Jupyter Notebook Access',
        'TensorFlow & PyTorch Ready',
        '24/7 Support'
      ]
    },
    {
      id: 'ml-professional',
      name: 'ML Professional',
      type: 'ml',
      cpu: 8,
      ram: 32,
      storage: 250,
      gpu: 'NVIDIA T4 (16GB)',
      price: 299,
      popular: true,
      features: [
        'NVIDIA T4 GPU (16GB VRAM)',
        '8 vCPU Cores',
        '32 GB RAM',
        '250 GB SSD Storage',
        'CUDA & cuDNN Pre-installed',
        'Jupyter Notebook Access',
        'TensorFlow & PyTorch Ready',
        'Docker Support',
        'Custom ML Frameworks',
        '24/7 Priority Support'
      ]
    },
    {
      id: 'ml-enterprise',
      name: 'ML Enterprise',
      type: 'ml',
      cpu: 16,
      ram: 64,
      storage: 500,
      gpu: '2x NVIDIA T4 (32GB)',
      price: 599,
      features: [
        '2x NVIDIA T4 GPU (32GB VRAM)',
        '16 vCPU Cores',
        '64 GB RAM',
        '500 GB SSD Storage',
        'CUDA & cuDNN Pre-installed',
        'Jupyter Notebook Access',
        'TensorFlow & PyTorch Ready',
        'Docker & Kubernetes Support',
        'Custom ML Frameworks',
        'Dedicated Support Manager',
        'Multi-GPU Training Support'
      ]
    },
    {
      id: 'ml-ultimate',
      name: 'ML Ultimate',
      type: 'ml',
      cpu: 32,
      ram: 128,
      storage: 1000,
      gpu: '4x NVIDIA T4 (64GB)',
      price: 1199,
      features: [
        '4x NVIDIA T4 GPU (64GB VRAM)',
        '32 vCPU Cores',
        '128 GB RAM',
        '1000 GB SSD Storage',
        'CUDA & cuDNN Pre-installed',
        'Jupyter Notebook Access',
        'TensorFlow & PyTorch Ready',
        'Docker & Kubernetes Support',
        'Custom ML Frameworks',
        'Dedicated Support Manager',
        'Multi-GPU Training Support',
        'Priority Resource Allocation',
        'Custom Infrastructure Setup'
      ]
    }
  ];

  const currentPlans = activeTab === 'vps' ? vpsPlans : mlPlans;

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-indigo-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Choose Your Perfect Cloud Solution
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            From high-performance VPS to GPU-powered machine learning instances, 
            we have the right infrastructure for your needs.
          </p>
        </div>
      </section>

      {/* Service Tabs */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center mb-12">
            <div className="bg-gray-100 p-1 rounded-lg">
              <button
                onClick={() => setActiveTab('vps')}
                className={`px-8 py-3 rounded-md font-semibold transition-all ${
                  activeTab === 'vps'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                <Server className="h-5 w-5 inline-block mr-2" />
                Cloud VPS
              </button>
              <button
                onClick={() => setActiveTab('ml')}
                className={`px-8 py-3 rounded-md font-semibold transition-all ${
                  activeTab === 'ml'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-purple-600'
                }`}
              >
                <Cpu className="h-5 w-5 inline-block mr-2" />
                ML GPU Cloud
              </button>
            </div>
          </div>

          {/* Service Plans */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {currentPlans.map((plan) => (
              <div
                key={plan.id}
                className={`bg-white rounded-xl shadow-lg p-8 border-2 hover:shadow-xl transition-all duration-300 relative ${
                  plan.popular
                    ? activeTab === 'vps'
                      ? 'border-blue-300 transform scale-105'
                      : 'border-purple-300 transform scale-105'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span
                      className={`px-4 py-1 rounded-full text-sm font-semibold text-white ${
                        activeTab === 'vps' ? 'bg-blue-600' : 'bg-purple-600'
                      }`}
                    >
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <div className="text-4xl font-bold mb-2">
                    <span
                      className={activeTab === 'vps' ? 'text-blue-600' : 'text-purple-600'}
                    >
                      ${plan.price}
                    </span>
                    <span className="text-lg text-gray-500">/month</span>
                  </div>
                </div>

                {/* Specifications */}
                <div className="mb-6 space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">CPU</span>
                    <span className="font-semibold">{plan.cpu} vCores</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">RAM</span>
                    <span className="font-semibold">{plan.ram} GB</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Storage</span>
                    <span className="font-semibold">{plan.storage} GB SSD</span>
                  </div>
                  {plan.gpu && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">GPU</span>
                      <span className="font-semibold text-purple-600">{plan.gpu}</span>
                    </div>
                  )}
                </div>

                {/* Features */}
                <ul className="space-y-2 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-3 text-sm">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link
                  to={`/checkout/${plan.id}`}
                  className={`w-full py-3 rounded-lg font-semibold transition-colors text-center block ${
                    plan.popular
                      ? activeTab === 'vps'
                        ? 'bg-blue-600 text-white hover:bg-blue-700'
                        : 'bg-purple-600 text-white hover:bg-purple-700'
                      : activeTab === 'vps'
                      ? 'bg-blue-50 text-blue-600 hover:bg-blue-100 border border-blue-200'
                      : 'bg-purple-50 text-purple-600 hover:bg-purple-100 border border-purple-200'
                  }`}
                >
                  Get Started
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Features */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Included with Every Plan
            </h2>
            <p className="text-xl text-gray-600">
              Premium features and support included at no extra cost
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Zap className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Instant Deployment</h3>
              <p className="text-gray-600">
                Your servers are deployed and ready to use within minutes of ordering.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <HardDrive className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">NVMe SSD Storage</h3>
              <p className="text-gray-600">
                Ultra-fast NVMe SSD storage for maximum performance and reliability.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Server className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Full Root Access</h3>
              <p className="text-gray-600">
                Complete control over your server with full root access and custom configurations.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ServicesPage;