import React, { createContext, useContext, useState } from 'react';

interface Service {
  id: string;
  name: string;
  type: 'vps' | 'ml';
  cpu: number;
  ram: number;
  storage: number;
  gpu?: string;
  price: number;
  status: 'active' | 'stopped' | 'pending';
  createdAt: string;
}

interface UserContextType {
  services: Service[];
  addService: (service: Omit<Service, 'id' | 'createdAt' | 'status'>) => void;
  removeService: (id: string) => void;
  updateServiceStatus: (id: string, status: Service['status']) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [services, setServices] = useState<Service[]>([]);

  const addService = (serviceData: Omit<Service, 'id' | 'createdAt' | 'status'>) => {
    const newService: Service = {
      ...serviceData,
      id: Date.now().toString(),
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    setServices(prev => [...prev, newService]);
  };

  const removeService = (id: string) => {
    setServices(prev => prev.filter(service => service.id !== id));
  };

  const updateServiceStatus = (id: string, status: Service['status']) => {
    setServices(prev => 
      prev.map(service => 
        service.id === id ? { ...service, status } : service
      )
    );
  };

  return (
    <UserContext.Provider value={{ services, addService, removeService, updateServiceStatus }}>
      {children}
    </UserContext.Provider>
  );
};