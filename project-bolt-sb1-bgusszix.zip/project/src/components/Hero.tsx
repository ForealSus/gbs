import React from 'react';
import { ArrowRight, Zap, Shield, Cpu } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="pt-16 min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-emerald-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                VPS & ML Hosting
                <span className="bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
                  {' '}Berkualitas Rumahan
                </span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed">
                Solusi hosting VPS dan Machine Learning dengan spesifikasi tinggi, 
                harga terjangkau, dan dukungan 24/7. Infrastruktur rumahan dengan 
                performa enterprise.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:from-blue-700 hover:to-emerald-700 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2">
                <span>Mulai Hosting</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="border-2 border-white/30 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white/10 transition-all duration-300">
                Lihat Demo
              </button>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="bg-blue-600/20 p-3 rounded-full w-fit mx-auto mb-2">
                  <Zap className="h-6 w-6 text-blue-400" />
                </div>
                <p className="text-sm text-gray-300">Setup Instan</p>
              </div>
              <div className="text-center">
                <div className="bg-emerald-600/20 p-3 rounded-full w-fit mx-auto mb-2">
                  <Shield className="h-6 w-6 text-emerald-400" />
                </div>
                <p className="text-sm text-gray-300">99.9% Uptime</p>
              </div>
              <div className="text-center">
                <div className="bg-orange-600/20 p-3 rounded-full w-fit mx-auto mb-2">
                  <Cpu className="h-6 w-6 text-orange-400" />
                </div>
                <p className="text-sm text-gray-300">Performa Tinggi</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="bg-gradient-to-r from-blue-600/20 to-emerald-600/20 rounded-2xl p-8 backdrop-blur-sm border border-white/10">
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">Server Specs Unggulan</h3>
                  <p className="text-gray-300">Spesifikasi rumahan dengan performa maksimal</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/5 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-400">CPU</h4>
                    <p className="text-sm text-gray-300">Intel i7-12700K</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-lg">
                    <h4 className="font-semibold text-emerald-400">RAM</h4>
                    <p className="text-sm text-gray-300">32GB DDR4</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-lg">
                    <h4 className="font-semibold text-orange-400">Storage</h4>
                    <p className="text-sm text-gray-300">1TB NVMe SSD</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-lg">
                    <h4 className="font-semibold text-purple-400">Network</h4>
                    <p className="text-sm text-gray-300">1Gbps</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;