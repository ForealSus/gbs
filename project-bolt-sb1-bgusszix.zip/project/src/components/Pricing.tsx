import React from 'react';
import { Check, Star } from 'lucide-react';

const Pricing = () => {
  const plans = [
    {
      name: 'Starter VPS',
      price: '150K',
      period: '/bulan',
      description: 'Perfect untuk website personal dan proyek kecil',
      features: [
        '2 CPU Cores',
        '4GB RAM',
        '50GB SSD Storage',
        '1TB Bandwidth',
        'Ubuntu/CentOS',
        'Root Access',
        'Basic Support'
      ],
      popular: false,
      color: 'gray'
    },
    {
      name: 'Professional VPS',
      price: '300K',
      period: '/bulan',
      description: 'Ideal untuk aplikasi bisnis dan development',
      features: [
        '4 CPU Cores',
        '8GB RAM',
        '100GB SSD Storage',
        '2TB Bandwidth',
        'Multiple OS Options',
        'Root Access',
        'Priority Support',
        'Free SSL Certificate'
      ],
      popular: true,
      color: 'blue'
    },
    {
      name: 'ML Training Server',
      price: '2.5JT',
      period: '/bulan',
      description: 'Server khusus untuk machine learning dan AI',
      features: [
        '8 CPU Cores',
        '32GB RAM',
        '500GB NVMe SSD',
        'NVIDIA RTX 4090',
        'CUDA 12.0',
        'Python ML Stack',
        'Jupyter Notebook',
        '24/7 Expert Support'
      ],
      popular: false,
      color: 'emerald'
    }
  ];

  const getColorClasses = (color: string, popular: boolean) => {
    if (popular) {
      return {
        border: 'border-blue-500 shadow-2xl scale-105',
        button: 'bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700',
        badge: 'bg-gradient-to-r from-blue-600 to-emerald-600'
      };
    }
    
    const colors = {
      gray: {
        border: 'border-gray-200',
        button: 'bg-gray-800 hover:bg-gray-900',
        badge: 'bg-gray-800'
      },
      emerald: {
        border: 'border-gray-200',
        button: 'bg-emerald-600 hover:bg-emerald-700',
        badge: 'bg-emerald-600'
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Harga Transparan & Terjangkau
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Pilih paket yang sesuai dengan kebutuhan Anda. Semua paket include bandwidth unlimited 
            dan support 24/7 tanpa biaya tersembunyi.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => {
            const colors = getColorClasses(plan.color, plan.popular);
            
            return (
              <div
                key={index}
                className={`relative bg-white rounded-2xl p-8 border-2 transition-all duration-300 hover:shadow-xl ${colors.border}`}
              >
                {plan.popular && (
                  <div className={`absolute -top-4 left-1/2 transform -translate-x-1/2 px-6 py-2 rounded-full text-white text-sm font-semibold ${colors.badge}`}>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4" />
                      <span>Paling Populer</span>
                    </div>
                  </div>
                )}

                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-4">{plan.description}</p>
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-gray-900">Rp{plan.price}</span>
                    <span className="text-gray-600 ml-1">{plan.period}</span>
                  </div>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center">
                      <div className="bg-green-100 p-1 rounded-full mr-3">
                        <Check className="h-4 w-4 text-green-600" />
                      </div>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-4 rounded-lg text-white font-semibold transition-all duration-300 transform hover:scale-105 ${colors.button}`}>
                  Pilih {plan.name}
                </button>
              </div>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gray-50 rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Butuh Spesifikasi Custom?
            </h3>
            <p className="text-gray-600 mb-6">
              Kami juga menyediakan paket custom sesuai kebutuhan spesifik Anda. 
              Konsultasi gratis dengan tim teknis kami untuk mendapatkan solusi terbaik.
            </p>
            <button className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-emerald-700 transition-all duration-300">
              Konsultasi Gratis
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;