import React from 'react';
import { Server, Brain, Zap, Shield, Cloud } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Server,
      title: 'VPS Hosting',
      description: 'Server virtual pribadi dengan kontrol penuh, cocok untuk website, aplikasi, dan development.',
      features: ['Root Access', 'Custom OS', 'SSD Storage', '24/7 Monitoring'],
      color: 'blue'
    },
    {
      icon: Brain,
      title: 'ML Training Server',
      description: 'Server khusus machine learning dengan GPU support untuk training model AI Anda.',
      features: ['NVIDIA RTX 4090', 'CUDA Support', 'Python Environment', 'Jupyter Notebook'],
      color: 'emerald'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-600/10 text-blue-600 group-hover:bg-blue-600 group-hover:text-white',
      emerald: 'bg-emerald-600/10 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white'
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Layanan Hosting Terdepan
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Dari VPS tradisional hingga server machine learning khusus, 
            kami menyediakan infrastruktur yang Anda butuhkan dengan harga terjangkau.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {services.map((service, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className={`p-4 rounded-2xl w-fit mb-6 transition-all duration-300 ${getColorClasses(service.color)}`}>
                <service.icon className="h-8 w-8" />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
              
              <ul className="space-y-3 mb-8">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-700">
                    <div className="w-2 h-2 bg-gradient-to-r from-blue-600 to-emerald-600 rounded-full mr-3"></div>
                    {feature}
                  </li>
                ))}
              </ul>
              
              <button className="w-full bg-gradient-to-r from-gray-800 to-gray-900 text-white py-3 rounded-lg hover:from-blue-600 hover:to-emerald-600 transition-all duration-300 font-semibold">
                Pilih Paket
              </button>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 to-emerald-600 rounded-2xl p-8 text-white">
          <div className="grid md:grid-cols-3 gap-8 items-center">
            <div className="text-center">
              <Zap className="h-12 w-12 mx-auto mb-4 text-yellow-300" />
              <h4 className="text-xl font-bold mb-2">Setup 5 Menit</h4>
              <p className="text-blue-100">Server siap dalam hitungan menit</p>
            </div>
            <div className="text-center">
              <Shield className="h-12 w-12 mx-auto mb-4 text-green-300" />
              <h4 className="text-xl font-bold mb-2">Backup Harian</h4>
              <p className="text-blue-100">Data Anda aman dengan backup otomatis</p>
            </div>
            <div className="text-center">
              <Cloud className="h-12 w-12 mx-auto mb-4 text-purple-300" />
              <h4 className="text-xl font-bold mb-2">Support 24/7</h4>
              <p className="text-blue-100">Tim teknis siap membantu kapan saja</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;