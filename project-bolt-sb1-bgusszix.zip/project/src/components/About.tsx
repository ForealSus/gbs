import React from 'react';
import { Users, Award, Headphones, Zap } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: Users, label: 'Pelanggan Aktif', value: '500+' },
    { icon: Award, label: 'Uptime Guarantee', value: '99.9%' },
    { icon: Headphones, label: 'Response Time', value: '<2 menit' },
    { icon: Zap, label: 'Server Locations', value: '3 Kota' }
  ];

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Mengapa Memilih ALO CLOUD?
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed mb-6">
                ALO CLOUD adalah penyedia hosting VPS dan machine learning terpercaya 
                dengan infrastruktur rumahan berkualitas enterprise. Kami mengutamakan 
                performa, keandalan, dan dukungan pelanggan yang luar biasa.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Dengan pengalaman lebih dari 5 tahun di industri hosting, kami memahami 
                kebutuhan developer dan bisnis modern. Setiap server dikelola dengan standar 
                profesional untuk memastikan aplikasi Anda berjalan optimal 24/7.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="bg-gradient-to-r from-blue-600 to-emerald-600 p-2 rounded-lg">
                      <stat.icon className="h-5 w-5 text-white" />
                    </div>
                    <span className="text-2xl font-bold text-gray-900">{stat.value}</span>
                  </div>
                  <p className="text-gray-600 text-sm">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Keunggulan Kami</h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Hardware Premium</h4>
                    <p className="text-gray-600 text-sm">Menggunakan komponen terbaru dengan cooling system optimal</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full mt-2"></div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Network Redundancy</h4>
                    <p className="text-gray-600 text-sm">Multi-provider internet dengan failover otomatis</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mt-2"></div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Monitoring 24/7</h4>
                    <p className="text-gray-600 text-sm">Tim teknis siaga memantau infrastruktur setiap saat</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-purple-600 rounded-full mt-2"></div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Backup Otomatis</h4>
                    <p className="text-gray-600 text-sm">Data backup harian dengan retention 30 hari</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-600 to-emerald-600 p-8 rounded-2xl text-white">
              <h3 className="text-xl font-bold mb-4">Komitmen Kami</h3>
              <p className="leading-relaxed">
                "Memberikan layanan hosting terbaik dengan harga terjangkau, 
                sehingga setiap developer dan bisnis dapat fokus pada inovasi 
                tanpa khawatir tentang infrastruktur."
              </p>
              <div className="mt-4 pt-4 border-t border-white/20">
                <p className="font-semibold">- Tim ALO CLOUD</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;