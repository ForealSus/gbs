import os
import pandas as pd
import re

def extract_ips_from_csv(csv_filename):
    ip_pattern = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
    ip_list = set()
    
    try:
        df = pd.read_csv(csv_filename, dtype=str, on_bad_lines='skip', engine='python')
    except Exception:
        df = pd.read_csv(csv_filename, dtype=str, delimiter="\t", on_bad_lines='skip', engine='python')
    
    for col in df.columns:
        df[col] = df[col].astype(str)
        for value in df[col].dropna():
            ips = ip_pattern.findall(value)
            ip_list.update(ips)
    
    return sorted(ip_list)

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    csv_files = [f for f in os.listdir(script_dir) if f.endswith('.csv')]
    
    if not csv_files:
        print("Tidak ada file CSV di direktori script.")
        return
    
    csv_filename = os.path.join(script_dir, csv_files[0])
    print(f"Memproses file: {csv_filename}")
    
    ip_addresses = extract_ips_from_csv(csv_filename)
    
    if ip_addresses:
        iplist_path = os.path.join(script_dir, "iplist.txt")
        with open(iplist_path, "w") as f:
            f.write("\n".join(ip_addresses))
        print(f"Daftar IP telah disimpan di {iplist_path}")
    else:
        print("Tidak ditemukan IP dalam file CSV.")

if __name__ == "__main__":
    main()
