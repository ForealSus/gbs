import ipaddress
import random
import multiprocessing

def generate_ips(existing_ips, queue, count):
    new_ips = set()
    while len(new_ips) < count:
        random_subnet = f"{random.randint(1, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}"
        network = ipaddress.IPv4Network(f"{random_subnet}.0/24", strict=False)
        for _ in range(100):
            new_ip = str(network[random.randint(1, 254)])
            if new_ip not in existing_ips and new_ip not in new_ips:
                new_ips.add(new_ip)
            if len(new_ips) >= count:
                break
    queue.put(new_ips)

def main():
    # Baca IP asli dari file untuk di-exclude
    with open('iplist.txt', 'r') as f:
        existing_ips = {line.strip() for line in f if line.strip()}
    
    target_count = 10_000_000
    num_workers = multiprocessing.cpu_count()
    count_per_worker = target_count // num_workers
    queue = multiprocessing.Queue()
    
    # Buat proses untuk generate IP secara paralel
    processes = []
    for _ in range(num_workers):
        p = multiprocessing.Process(target=generate_ips, args=(existing_ips, queue, count_per_worker))
        p.start()
        processes.append(p)
    
    # Kumpulkan hasil dari semua proses
    new_ips = set()
    for _ in range(num_workers):
        new_ips.update(queue.get())
    
    for p in processes:
        p.join()
    
    # Simpan ke file
    with open('new_iplist.txt', 'w') as f:
        for ip in new_ips:
            f.write(f"{ip}\n")
    
    print(f"Generated {len(new_ips)} unique IPs in new_iplist.txt")

if __name__ == "__main__":
    main()
