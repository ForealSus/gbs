import os
import pandas as pd
import re

def extract_ips_from_csv(csv_filename):
    ip_pattern = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
    ip_list = set()
    
    try:
        df = pd.read_csv(csv_filename, dtype=str, on_bad_lines='skip', engine='python')
    except Exception:
        try:
            df = pd.read_csv(csv_filename, dtype=str, delimiter="\t", on_bad_lines='skip', engine='python')
        except Exception as e:
            print(f"Gagal memproses file {csv_filename}: {str(e)}")
            return ip_list
    
    for col in df.columns:
        df[col] = df[col].astype(str)
        for value in df[col].dropna():
            ips = ip_pattern.findall(value)
            ip_list.update(ips)
    
    return ip_list

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    csv_files = [f for f in os.listdir(script_dir) if f.endswith('.csv')]
    
    if not csv_files:
        print("Tidak ada file CSV di direktori script.")
        return
    
    all_ips = set()
    
    for csv_file in csv_files:
        csv_path = os.path.join(script_dir, csv_file)
        print(f"Memproses file: {csv_path}")
        ip_addresses = extract_ips_from_csv(csv_path)
        if ip_addresses:
            all_ips.update(ip_addresses)
            print(f"Ditemukan {len(ip_addresses)} IP unik di file {csv_file}")
        else:
            print(f"Tidak ditemukan IP dalam file {csv_file}")
    
    if all_ips:
        iplist_path = os.path.join(script_dir, "iplist.txt")
        with open(iplist_path, "w") as f:
            f.write("\n".join(sorted(all_ips)))
        print(f"\nTotal {len(all_ips)} IP unik ditemukan dari semua file CSV")
        print(f"Daftar IP telah disimpan di {iplist_path}")
    else:
        print("Tidak ditemukan IP di semua file CSV.")

if __name__ == "__main__":
    main()