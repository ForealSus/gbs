import React, { useState } from 'react';
import { Copy, Check, Code, Zap, Settings } from 'lucide-react';

const GettingStarted = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const codeExamples = [
    {
      title: "HTML Integration",
      description: "Replace your asset URLs with our CDN URLs",
      code: `<!-- Before -->
<img src="/images/hero.jpg" alt="Hero Image">

<!-- After -->
<img src="https://cdn.fastcdn.com/your-zone/images/hero.jpg" alt="Hero Image">`
    },
    {
      title: "JavaScript API",
      description: "Programmatically manage your CDN resources",
      code: `// Initialize FastCDN client
const fastcdn = new FastCDN({
  apiKey: 'your-api-key',
  zone: 'your-zone-id'
});

// Purge cache
await fastcdn.purge(['/images/updated-hero.jpg']);

// Get analytics
const stats = await fastcdn.getAnalytics();`
    },
    {
      title: "WordPress Plugin",
      description: "Automatically optimize your WordPress site",
      code: `// Install via WordPress admin or WP-CLI
wp plugin install fastcdn --activate

// Configure in wp-config.php
define('FASTCDN_API_KEY', 'your-api-key');
define('FASTCDN_ZONE', 'your-zone-id');`
    }
  ];

  const steps = [
    {
      icon: <Code className="h-8 w-8" />,
      title: "Sign Up & Configure",
      description: "Create your account and set up your first CDN zone in minutes.",
      color: "text-blue-600 bg-blue-100"
    },
    {
      icon: <Settings className="h-8 w-8" />,
      title: "Update Your URLs",
      description: "Point your static assets to our CDN URLs or use our automatic integration.",
      color: "text-green-600 bg-green-100"
    },
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Go Live",
      description: "Your content is now cached globally and delivered at lightning speed.",
      color: "text-purple-600 bg-purple-100"
    }
  ];

  const copyToClipboard = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <section id="docs" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Get Started in Minutes
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Integrate our CDN with just a few lines of code. No complex setup required.
          </p>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {steps.map((step, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 text-center shadow-lg">
              <div className={`inline-flex p-4 rounded-2xl ${step.color} mb-6`}>
                {step.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{step.title}</h3>
              <p className="text-gray-600 leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>

        {/* Code Examples */}
        <div className="space-y-8">
          {codeExamples.map((example, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{example.title}</h3>
                <p className="text-gray-600">{example.description}</p>
              </div>
              <div className="relative">
                <button
                  onClick={() => copyToClipboard(example.code, index)}
                  className="absolute top-4 right-4 p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                >
                  {copiedIndex === index ? (
                    <Check className="h-5 w-5 text-green-600" />
                  ) : (
                    <Copy className="h-5 w-5 text-gray-600" />
                  )}
                </button>
                <pre className="p-6 bg-gray-900 text-gray-300 overflow-x-auto">
                  <code>{example.code}</code>
                </pre>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-white rounded-2xl p-8 shadow-lg inline-block">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready to get started?</h3>
            <p className="text-gray-600 mb-6">
              Join thousands of developers who trust FastCDN for their content delivery needs.
            </p>
            <button className="bg-blue-600 text-white px-8 py-4 rounded-xl hover:bg-blue-700 transition-colors font-semibold">
              Start Your Free Trial
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GettingStarted;