import React from 'react';
import { 
  Zap, 
  Shield, 
  Globe, 
  BarChart3, 
  Lock, 
  RefreshCw,
  CloudLightning,
  Smartphone,
  FileText
} from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Lightning Fast Performance",
      description: "Deliver content in milliseconds with our globally distributed edge servers and advanced caching algorithms.",
      color: "text-yellow-600 bg-yellow-100"
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "DDoS Protection",
      description: "Built-in security features protect your website from malicious attacks and ensure constant availability.",
      color: "text-green-600 bg-green-100"
    },
    {
      icon: <Globe className="h-8 w-8" />,
      title: "Global Network",
      description: "180+ strategically placed edge locations across 6 continents ensure optimal performance worldwide.",
      color: "text-blue-600 bg-blue-100"
    },
    {
      icon: <BarChart3 className="h-8 w-8" />,
      title: "Real-time Analytics",
      description: "Monitor your CDN performance with detailed analytics, traffic insights, and performance metrics.",
      color: "text-purple-600 bg-purple-100"
    },
    {
      icon: <Lock className="h-8 w-8" />,
      title: "SSL/TLS Encryption",
      description: "Free SSL certificates and end-to-end encryption protect your data and improve SEO rankings.",
      color: "text-red-600 bg-red-100"
    },
    {
      icon: <RefreshCw className="h-8 w-8" />,
      title: "Instant Cache Purge",
      description: "Update your content instantly across all edge servers with our real-time cache invalidation system.",
      color: "text-indigo-600 bg-indigo-100"
    },
    {
      icon: <CloudLightning className="h-8 w-8" />,
      title: "Edge Computing",
      description: "Run serverless functions at the edge for dynamic content generation and API acceleration.",
      color: "text-cyan-600 bg-cyan-100"
    },
    {
      icon: <Smartphone className="h-8 w-8" />,
      title: "Mobile Optimization",
      description: "Automatic image optimization and compression for mobile devices to ensure fast mobile experiences.",
      color: "text-pink-600 bg-pink-100"
    },
    {
      icon: <FileText className="h-8 w-8" />,
      title: "API Integration",
      description: "RESTful APIs and webhooks for seamless integration with your existing workflow and applications.",
      color: "text-orange-600 bg-orange-100"
    }
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Powerful Features
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Everything you need to deliver fast, secure, and reliable content to your users worldwide.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 border border-gray-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group"
            >
              <div className={`inline-flex p-3 rounded-xl ${feature.color} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;